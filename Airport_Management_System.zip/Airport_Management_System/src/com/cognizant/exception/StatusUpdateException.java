package com.cognizant.exception;

public class StatusUpdateException extends NullPointerException {
	private String message;
	
	public StatusUpdateException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}
	
}
